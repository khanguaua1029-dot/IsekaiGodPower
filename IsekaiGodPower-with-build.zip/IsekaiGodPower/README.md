# Isekai: Tuyệt Đối Chi Lực

Game Android 2D pixel bản demo.

## Tính năng
- Nhân vật isekai nam với sức mạnh bá đạo.
- Điều khiển cảm ứng ngang màn hình.
- Đánh thường: hạ quái trong tầm gần.
- Tuyệt kỹ: quét sạch toàn bộ quái trên bản đồ.
- EXP và level.
- Không dùng thư viện game bên ngoài.

## Build APK
Mở thư mục này bằng Android Studio hoặc app Android có hỗ trợ Gradle/Android project, sau đó build APK.
Application ID: `com.bon.isekai`
